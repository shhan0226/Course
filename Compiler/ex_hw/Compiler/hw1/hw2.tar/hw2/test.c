main()
{
   /* this is a test program */

   int index, jj2;
   float fval, g12g, !;

   if (index == jj2) fval = g12g;
   else g12g = 123; #
}
