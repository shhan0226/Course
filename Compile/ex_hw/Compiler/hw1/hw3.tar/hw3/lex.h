#define TK_IDENTIFIER   256
#define TK_PLUS         257
#define TK_MULT         258
#define TK_LPAR         259
#define TK_RPAR         260
#define TK_EOF            0
